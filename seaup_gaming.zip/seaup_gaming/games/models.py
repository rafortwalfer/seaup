from django.db import models

class Game(models.Model):
    VIDEOGAME = "Video Game"
    MULTIPLAYER = "MultiPlayer"
    ACTIONADVENTURE = "Action/Adventure"
    ROLEPLAYING = "Role-Playing"
    STRATEGY = "Strategy"
    SIMULATION = "Simulation"
    SPORTS = "Sports"
    PUZZLE = "Puzzle"
    CARDBOARD = "Card/Board Games"
    SHOOTER = "Shooter"
    RACING = "Racing"
    CATEGORY_CHOICES = {
        ACTIONADVENTURE : "Action/Adventure",
        ROLEPLAYING: "Role Playing",
        STRATEGY: "Strategy",
        SIMULATION: "Simulation",
        SPORTS: "Sports",
        PUZZLE : "Puzzle",
        CARDBOARD : "Card/Board",
        SHOOTER : "Shooter",
        RACING : "Racing",
        VIDEOGAME : "Video Game",
        MULTIPLAYER : "Multiplayer"
    }
    id = models.IntegerField(primary_key=True)
    title = models.CharField(max_length=255)
    logo = models.URLField()
    script = models.URLField()
    other_script = models.URLField()
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES, default=VIDEOGAME)
    description = models.TextField()
    upload_date = models.DateField(auto_now_add=True)
    

    def __str__(self):
        return self.title