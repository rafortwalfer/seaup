from django.urls import path
from . import views
from .views import game
from django.conf.urls import handler404
from .views import search_games

urlpatterns = [
    path('', views.homepage , name='homepage'),
    path('game_list', views.game_list, name='game_list'),
    path('games/<int:game_id>/', game, name='game'),
    path('search/', search_games, name='search_games'),
]

handler404 = views.error_404 

