from django.shortcuts import render, get_object_or_404
from django.db.models import Q 
from .models import Game

def homepage(request):
    racing_games = Game.objects.filter(category=Game.RACING)
    shooter_games = Game.objects.filter(category=Game.SHOOTER)
    cardboard_games = Game.objects.filter(category=Game.CARDBOARD)
    puzzle_games = Game.objects.filter(category=Game.PUZZLE)
    sports_games = Game.objects.filter(category=Game.SPORTS)
    simmulation_games = Game.objects.filter(category=Game.SIMULATION)
    strategy_games = Game.objects.filter(category=Game.STRATEGY)
    role_playing_games = Game.objects.filter(category=Game.ROLEPLAYING)
    multiplayer_games = Game.objects.filter(category=Game.MULTIPLAYER)
    video_game_games = Game.objects.filter(category=Game.VIDEOGAME)
    action_adventure_games = Game.objects.filter(category=Game.ACTIONADVENTURE)
    return render(request, 'index.html', {
        'action_adventure_games': action_adventure_games,
        'video_game_games' : video_game_games,
        'multiplayer_games' : multiplayer_games,
        'role_playing_games' : role_playing_games,
        'racing_games': racing_games,
        'shooter_games': shooter_games,
        'cardboard_games' : cardboard_games,
        'puzzle_games' : puzzle_games,
        'sports_games' : sports_games,
        'simmulation_games' : simmulation_games,
        'strategy_games': strategy_games
        })

def game_list(request):
    games = Game.objects.all()
    return render(request, 'game_list.html', {'games': games})


def game(request, game_id):
    game = get_object_or_404(Game, pk=game_id)
    return render(request, 'game.html', {'game': game})

def search_games(request):
    query = request.GET.get('q')
    if query:
        # Strip whitespace from the query
        query = query.strip()
        # Perform case-insensitive search based on title and category
        search_results = Game.objects.filter(
            Q(title__icontains=query) | 
            Q(category__icontains=query)
        )
    else:
        search_results = None
    return render(request, 'search_results.html', {'search_results': search_results})


def error_404(request, exception):
    return render(request, '404.html', status=404)
