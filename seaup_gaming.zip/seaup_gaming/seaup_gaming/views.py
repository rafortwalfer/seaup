from django.shortcuts import HttpResponse, HttpResponseRedirect
from django.shortcuts import render

